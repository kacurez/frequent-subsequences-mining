import os,sys
import Gnuplot as gp
from time import sleep

def parsefilename(filename):
  #test1.data-prefixspan-100-.o6958 => test1,prefixspan,100
	parts = filename.split("-",3);
	parts[0] = (parts[0].split(".",1))[0]	
	return parts
def GetDbLens(filename):
	ret = {}
	f = open(filename)
	for line in f:
		data = line.split()
		ret[data[0]] = data[1]
	return ret		
	
class MyGraf:
	def __init__(self):	  
	  self.xys = {}
	def AddXY(self,x,y,alg):
		if alg not in self.xys.keys():
			self.xys[alg]={}
		tmp = self.xys[alg]
		tmp[x]=y
		self.xys[alg] = tmp    

if len(sys.argv) > 1:
  mydir = sys.argv[1]
else:
  mydir = os.curdir
dirlist = os.listdir(mydir)


  
grafy = {}
dblens = {}
if len(sys.argv) > 2:
  dblens = GetDbLens(sys.argv[2])
else:
  raise 'no dblens file as argument 2'
  
print dblens

for filename in dirlist:
	f = open(mydir + '/' + filename);	
	parts = parsefilename(filename)
	algtime = float((f.read()));
	print (parts,str(algtime))
	if parts[0] not in grafy.keys():
		grafy[str(parts[0])] = MyGraf()
	gr = 	grafy[str(parts[0])]
	#gr.AddX((int)(parts[2]))
	#gr.AddY(algtime,parts[1])
	gr.AddXY((int)(parts[2]),algtime,parts[1])
	grafy[parts[0]] = gr

for i in grafy:
 print i
 #print grafy[i].listx
 #print grafy[i].listy
 g = gp.Gnuplot(debug=1)
 g.title(i)
 g('set data style linespoints')
 #g('set ytics (10,30,40,50,80,100,120,140,160,180-1600)')
 #g('set logscale y')
 #g('set xtics (0.2,0.5,0.8,1,1.5,2,3,5,10,14)')
 g('set yrange [1:600]')
 #g('set xrange [1:12]')
 g.xlabel('support in %')
 g.ylabel('time in seconds')
 skeys = grafy[i].xys["spade"].keys()
 skeys.sort()
 spade_x = [float(x*100)/float(dblens[i]) for x in  skeys]
 print spade_x 
 spade_y = [grafy[i].xys["spade"][x] for x in skeys]
 print spade_y
 pkeys =  grafy[i].xys["prefixspan"].keys()
 pkeys.sort()
 prefixspan_x = [float(x*100)/float(dblens[i]) for x in  pkeys]
 prefixspan_y = [grafy[i].xys["prefixspan"][x] for x in pkeys]
 spade = gp.Data(spade_x, spade_y,
                     title='spade')
 prefixspan = gp.Data(prefixspan_x,prefixspan_y,title = 'prefixspan')
 #g.plot(zip(spade_x, spade_y),title='spade', zip(prefixspan_x,prefixspan_y),title='prefixspan')
 xlist = prefixspan_x
 xlist.extend(spade_x)
 minx = min(xlist)
 maxx = max(xlist)
 
 g('set xrange[' + str(minx) + ':' +str(maxx) + ']')
 g.plot(spade,prefixspan)    
 g.hardcopy(str(i)+'.ps', enhanced=0, color=1)
 print 'saved '+ str(i)+'.ps'
 raw_input()
 #sleep(1)	
 


		
